package org.codingdojo.animals.model;

public class Animal  {
	private String name;
	private String breed;
	private Double weight;	
	
	public Animal() {
		super();
	}

	public Animal(String name, String breed, Double weight) {
		super();
		this.name = name;
		this.breed = breed;
		this.weight = weight;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	
	
}
