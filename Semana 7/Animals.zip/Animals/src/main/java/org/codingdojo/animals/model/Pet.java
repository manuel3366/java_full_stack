package org.codingdojo.animals.model;

public interface Pet {
	String showAffection();
}
