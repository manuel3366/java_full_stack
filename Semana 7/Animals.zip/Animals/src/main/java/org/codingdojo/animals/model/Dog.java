package org.codingdojo.animals.model;

public class Dog extends Animal implements Pet {	
	
	public Dog(String name, String breed, Double weight) {
		super(name, breed, weight);
	}
	
	@Override
	public String showAffection() {
		String response = this.getName() + " hopped into you lap and cuddled you!";
		if (this.getWeight() >= 30) {
			response = this.getName() + " curled up next to you!";
		}
		return response;
	}
	
}
