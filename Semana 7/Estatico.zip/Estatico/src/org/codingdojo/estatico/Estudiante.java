package org.codingdojo.estatico;

public class Estudiante extends Persona{
	private Long idEstudiante;
	
	public Estudiante(String nombre, String apellidoPaterno) {
		super(nombre, apellidoPaterno);
	}
	
	@Override
	public void imprimirDatos() {
		super.imprimirDatos();
		System.out.println("Id Estudiante: " + this.idEstudiante);
	}

}
