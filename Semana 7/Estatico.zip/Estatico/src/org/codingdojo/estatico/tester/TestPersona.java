package org.codingdojo.estatico.tester;

import org.codingdojo.estatico.Estudiante;
import org.codingdojo.estatico.Persona;
import org.codingdojo.estatico.Servidor;

public class TestPersona {

	public static void main(String[] args) {
		String nombre = "Daniel";
		String apellidoPaterno = "Morales";
		Persona persona = new Persona(nombre, apellidoPaterno);
		persona.imprimirDatos();
		Persona.imprimirAplicacion();
		
		Estudiante estudiante = new Estudiante(nombre, apellidoPaterno);
		estudiante.imprimirDatos();
		
		System.out.println(estudiante instanceof Persona);
		
		Servidor servidor = Servidor.getInstance();
		
		Persona personaSystema = new Persona();
		personaSystema.setNombre("Martin");
		personaSystema.setApellidoPaterno("Victoriano");

	}

}
