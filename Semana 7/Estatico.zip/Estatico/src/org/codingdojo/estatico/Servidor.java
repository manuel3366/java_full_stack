package org.codingdojo.estatico;

public final class Servidor {
	private static Servidor servidor;
	private Servidor() {
		
	}
	
	public static Servidor getInstance() {
		if (servidor == null) {
			servidor = new Servidor();
		}
		return servidor;
	}
}
