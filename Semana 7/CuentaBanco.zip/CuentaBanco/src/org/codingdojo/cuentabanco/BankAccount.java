package org.codingdojo.cuentabanco;

public class BankAccount {
	private String numeroCuenta;
	private double saldoCuentaCorriente;
	private double saldoCuentaAhorros;
	
	private static int totalCuentasCreadas = 0;
	private static double dineroAlmacenado = 0.0;	
	
	public BankAccount() {
		super();
		this.numeroCuenta = generarNumeroCuentaRandom();
		totalCuentasCreadas++;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	public double getSaldoCuentaCorriente() {
		return saldoCuentaCorriente;
	}
	public void setSaldoCuentaCorriente(double saldoCuentaCorriente) {
		this.saldoCuentaCorriente = saldoCuentaCorriente;
	}
	public double getSaldoCuentaAhorros() {
		return saldoCuentaAhorros;
	}
	public void setSaldoCuentaAhorros(double saldoCuentaAhorros) {
		this.saldoCuentaAhorros = saldoCuentaAhorros;
	}
	
	private String generarNumeroCuentaRandom() {
		String numeroCuenta = "";		
		for (int i = 0; i < 10; i++) {
			numeroCuenta += Math.round(Math.random() * 10.0);
		}
		return numeroCuenta;
	}
	
	public void depositarDinero(double monto, String tipoCuenta) {
		if (tipoCuenta.equals("Ahorro")) {
			this.saldoCuentaAhorros += monto;
		} else {
			this.saldoCuentaCorriente += monto;
		}
		dineroAlmacenado += monto;
	}	
	
	
}
