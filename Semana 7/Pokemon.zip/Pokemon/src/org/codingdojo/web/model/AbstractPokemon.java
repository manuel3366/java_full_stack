package org.codingdojo.web.model;

import java.util.ArrayList;

import org.codingdojo.web.interfaces.PokemonInterface;

public abstract class AbstractPokemon implements PokemonInterface {
	protected ArrayList<Pokemon> myPokemons;		
	
	public AbstractPokemon() {
		super();
		this.myPokemons = new ArrayList<Pokemon>();
	}

	@Override
	public Pokemon createPokemon(String name, Integer health, String type) {
		Pokemon pokemon = new Pokemon(name, health, type);
		myPokemons.add(pokemon);
		return pokemon;
	}
	
	@Override
	public String pokemonInfo(Pokemon pokemon) {
		String respuesta = "Pokemon(Name=" + pokemon.getName()+ ", Health=" + pokemon.getHealth() + ", Type=" + pokemon.getType() + ")";
		
		return respuesta;
	}
}
