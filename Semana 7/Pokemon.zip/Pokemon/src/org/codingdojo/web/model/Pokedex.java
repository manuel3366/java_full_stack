package org.codingdojo.web.model;

public class Pokedex extends AbstractPokemon{	
	
	public Pokedex() {
		super();		
	}

	@Override
	public void listPokemon() {
		for (Pokemon pokemon: this.myPokemons) {
			System.out.println(this.pokemonInfo(pokemon));
		}		
	}

}
