package org.codingdojo.web;

import org.codingdojo.web.model.Pokedex;
import org.codingdojo.web.model.Pokemon;
import org.codingdojo.web.interfaces.PokemonInterface;

public class TestPokemon {
	public static void main(String[] args) {
		Pokedex pokedex = new Pokedex();
		testPokemon(pokedex);
	}
	
	public static void testPokemon(PokemonInterface pokedex) {
		Pokemon picachu = pokedex.createPokemon("Pikachu", 200, "Electrico");
		Pokemon charmander = pokedex.createPokemon("Charmander", 250, "Fuego");
		picachu.attackPokemon(charmander);
		pokedex.listPokemon();
	}
}
