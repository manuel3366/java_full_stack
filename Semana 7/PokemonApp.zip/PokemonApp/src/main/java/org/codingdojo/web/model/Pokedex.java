package org.codingdojo.web.model;

import java.util.ArrayList;

public class Pokedex {
	private static ArrayList<Pokemon> pokemonList = new ArrayList<Pokemon>();
	
	public static void addPokemon(Pokemon pokemon) {
		pokemonList.add(pokemon);
	}
	
	public static ArrayList<Pokemon> getPokemonList() {
		return pokemonList;
	}

}
