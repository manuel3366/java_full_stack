package org.codingdojo.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codingdojo.web.model.Pokemon;

/**
 * Servlet implementation class Pokemon
 */
@WebServlet("/Pokemon")
public class PokemonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PokemonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pokemonName = request.getParameter("pokemonName");
		String pokemonHealth = request.getParameter("pokemonHealth");
		String[] nameArray = pokemonName.split(",");
		String[] healthArray = pokemonHealth.split(",");
		
		ArrayList<Pokemon> pokemonList = new ArrayList<Pokemon>();
		String message = null;
		
		if (nameArray.length == healthArray.length) {		
			for(int i = 0; i < nameArray.length; i++) {
				String name = nameArray[i];
				Integer health = Integer.parseInt(healthArray[i]);
				Pokemon pokemon = new Pokemon(name, health);
				pokemonList.add(pokemon);
			}
		} else {
			message = "La lista de nombre y salud deben tener la misma cantidad de elementos.";
		}
		
		request.setAttribute("message", message);
		request.setAttribute("pokemonList", pokemonList);
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/views/pokemon.jsp");
		requestDispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
