package org.codingdojo.web.model;

import java.io.Serializable;

public class Pokemon implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String name;
	private Integer health;		
	
	public Pokemon() {
		super();
	}
	
	public Pokemon(String name, Integer health) {
		super();
		this.name = name;
		this.health = health;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getHealth() {
		return health;
	}
	public void setHealth(Integer health) {
		this.health = health;
	}
	
	
}
