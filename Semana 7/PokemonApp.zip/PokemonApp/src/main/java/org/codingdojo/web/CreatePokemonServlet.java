package org.codingdojo.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codingdojo.web.model.Pokedex;
import org.codingdojo.web.model.Pokemon;

/**
 * Servlet implementation class CreatePokemonServlet
 */
@WebServlet("/CreatePokemon")
public class CreatePokemonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreatePokemonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/views/createPokemon.jsp");
		requestDispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		Integer health = Integer.parseInt(request.getParameter("health"));
		
		Pokemon pokemon = new Pokemon(name, health);
		Pokedex.addPokemon(pokemon);
		
		request.setAttribute("pokemonList", Pokedex.getPokemonList());
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/views/pokedex.jsp");
		requestDispatcher.forward(request, response);
	}

}
