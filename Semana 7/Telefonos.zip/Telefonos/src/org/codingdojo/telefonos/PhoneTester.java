package org.codingdojo.telefonos;

import org.codingdojo.telefonos.model.IPhone;

public class PhoneTester {

	public static void main(String[] args) {
		IPhone iphone = new IPhone("X", 100, "AT&T", "Zing");
		System.out.println(iphone.ring());
		System.out.println(iphone.unlock());
		iphone.displayInfo();
	}

}
