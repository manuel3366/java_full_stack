package org.codingdojo.telefonos.model;

import org.codingdojo.telefonos.interfaces.Ringable;

public class IPhone extends Phone implements Ringable {

	public IPhone(String versionNumber, int batteryPercentage, String carrier, String ringTone) {
		super(versionNumber, batteryPercentage, carrier, ringTone);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String ring() {
		// TODO Auto-generated method stub
		return "Zoooooom";
	}

	@Override
	public String unlock() {
		// TODO Auto-generated method stub
		return "Desbloqueado";
	}

	@Override
	public void displayInfo() {
		System.out.println("Version Number:" + getVersionNumber());
	}

}
