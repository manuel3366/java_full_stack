package org.codingdojo.telefonos.interfaces;

public interface Ringable {
	String ring();
	String unlock();
}
