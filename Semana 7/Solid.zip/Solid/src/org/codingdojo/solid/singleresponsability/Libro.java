package org.codingdojo.solid.singleresponsability;

public class Libro {
	private String autor;
	private String titulo;
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	public Libro crearLibro(String titulo) {
		Libro libro = new Libro();
		libro.setTitulo(titulo);
		return libro;
	}	
	
}
