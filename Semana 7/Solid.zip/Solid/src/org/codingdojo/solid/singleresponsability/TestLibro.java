package org.codingdojo.solid.singleresponsability;

public class TestLibro {

	public static void main(String[] args) {
		Libro libro = new Libro();
		Libro libro2 = libro.crearLibro("Harry Potter y la piedra filosofal");
		ImpresorLibro impresor = new ImpresorLibro();
		impresor.imprimirTitulo(libro2);

	}

}
