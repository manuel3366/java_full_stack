package org.codingdojo.solid.singleresponsability;

public class ImpresorLibro {
	public void imprimirTitulo(Libro libro) {
		System.out.println("Titulo: " + libro.getTitulo());
	}
}
