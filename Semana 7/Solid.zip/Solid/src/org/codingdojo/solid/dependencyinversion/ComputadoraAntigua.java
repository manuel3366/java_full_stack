package org.codingdojo.solid.dependencyinversion;

public class ComputadoraAntigua {
	private Mouse mouse;
	
	
	public ComputadoraAntigua(Mouse mouse) {
		super();
		this.mouse = mouse;
	}

	public void operarComputadora() {
		this.mouse.moverMouse();
	}
}
