package org.codingdojo.solid.dependencyinversion;

public interface Mouse {
	void moverMouse();
}
