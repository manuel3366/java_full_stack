package org.codingdojo.solid.dependencyinversion;

public class TestComputadora {
	public static void main(String[] args) {
		probarMouseDeBolita();
		probarMouseOptico();
	}
	
	public static void probarMouseDeBolita() {
		Mouse mouse = new MouseDeBolita();
		ComputadoraAntigua computadoraAntigua = new ComputadoraAntigua(mouse);
		computadoraAntigua.operarComputadora();
	}
	
	public static void probarMouseOptico() {
		Mouse mouse = new MouseOptico();
		ComputadoraAntigua computadoraAntigua = new ComputadoraAntigua(mouse);
		computadoraAntigua.operarComputadora();
	}
}
