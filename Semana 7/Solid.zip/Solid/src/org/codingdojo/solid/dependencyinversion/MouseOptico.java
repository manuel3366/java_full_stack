package org.codingdojo.solid.dependencyinversion;

public class MouseOptico implements Mouse {

	@Override
	public void moverMouse() {
		System.out.println("Moviendo mosue con el laser.");
	}

}
