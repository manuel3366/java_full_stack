package org.codingdojo.solid.dependencyinversion;

public class MouseDeBolita implements Mouse {
	@Override
	public void moverMouse() {
		System.out.println("Moviendo mouse");
	}
}
