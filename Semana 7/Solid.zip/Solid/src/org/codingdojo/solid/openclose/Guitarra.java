package org.codingdojo.solid.openclose;

public class Guitarra {
	public void tocarNotasBasica() {
		System.out.println("Tocando la guitarra!!!!");
	}
}
