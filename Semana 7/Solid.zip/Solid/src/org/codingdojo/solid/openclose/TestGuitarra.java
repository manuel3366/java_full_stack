package org.codingdojo.solid.openclose;

public class TestGuitarra {

	public static void main(String[] args) {
		Guitarra guitarra = new Guitarra();
		guitarra.tocarNotasBasica();
		
		GuitarraElectrica guitarraElectrica = new GuitarraElectrica();
		guitarraElectrica.tocarNotasBasica();
		guitarraElectrica.soloDeGuitarraElectrica();

	}

}
