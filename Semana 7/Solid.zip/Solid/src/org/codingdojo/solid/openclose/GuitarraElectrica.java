package org.codingdojo.solid.openclose;

public class GuitarraElectrica extends Guitarra {
	public void soloDeGuitarraElectrica() {
		System.out.println("Tocando un solo!!!!!");
	}
}
