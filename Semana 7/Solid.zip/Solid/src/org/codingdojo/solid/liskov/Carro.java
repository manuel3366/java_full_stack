package org.codingdojo.solid.liskov;

public interface Carro {
	void iniciarMotor();
	void acelerar();
	void frenar();
}
