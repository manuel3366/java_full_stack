package org.codingdojo.solid.liskov;

public class AutomovilGasolinero implements Carro {

	@Override
	public void iniciarMotor() {
		System.out.println("Iniciando motor!!!");		
	}

	@Override
	public void acelerar() {
		System.out.println("Acelerando!!!");		
	}

	@Override
	public void frenar() {
		System.out.println("Frenando!!!");		
	}

}
