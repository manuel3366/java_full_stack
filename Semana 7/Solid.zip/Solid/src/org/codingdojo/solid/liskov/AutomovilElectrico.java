package org.codingdojo.solid.liskov;

public class AutomovilElectrico extends AutomovilGasolinero {
	
	@Override
	public void iniciarMotor()  {
		System.err.println("No puedo porque no tengo motor!!!");
	}
}
