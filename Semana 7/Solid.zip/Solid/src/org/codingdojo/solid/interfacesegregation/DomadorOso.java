package org.codingdojo.solid.interfacesegregation;

public interface DomadorOso {
	void asearOso();
	void alimentarOso();
	void entrenarOso();
}
