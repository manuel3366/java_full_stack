package org.codingdojo.solid.interfacesegregation;

public interface EntrenadorOso {
	void entrenarOso();
}
