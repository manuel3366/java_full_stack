package org.codingdojo.solid.interfacesegregation;

public interface AseadorOso {
	void asearOso();
}
