package org.codingdojo.solid.interfacesegregation;

public class CuidadorZoologico implements AlimentadorOso, AseadorOso {

	@Override
	public void asearOso() {
		System.out.println("Usando manguera para asear oso.");
	}

	@Override
	public void alimentarOso() {
		System.out.println("Llenando el plato del oso mientras no esta.");
	}

}
