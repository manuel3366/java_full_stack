package org.codingdojo.solid.interfacesegregation;

public interface AlimentadorOso {
	void alimentarOso();
}
