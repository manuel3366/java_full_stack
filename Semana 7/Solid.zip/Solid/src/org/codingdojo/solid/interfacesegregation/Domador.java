package org.codingdojo.solid.interfacesegregation;

public class Domador implements EntrenadorOso{

	@Override
	public void entrenarOso() {
		System.out.println("Entrenando oso, que para eso estudie.");		
	}

}
