package org.codingdojo.zoologico;

import org.codingdojo.zoologico.model.Bat;

public class BatTest {

	public static void main(String[] args) {
		Bat bat = new Bat();
		for(int i = 0; i < 3; i++) {
			bat.attackTown();
		}
		bat.displayEnergy();

	}

}
