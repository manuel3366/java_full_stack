package org.codingdojo.zoologico.model;

public class Bat extends Mammal {

	public Bat() {
		this.energyLevel = 300;
	}
	
	public void attackTown() {
		System.out.println("La ciudad esta siendo atacada por el murcielago.");
		this.energyLevel -= 100;
	}
	
}
