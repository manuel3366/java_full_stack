package org.codingdojo.zoologico.model;

public class Mammal {
	protected Integer energyLevel;
		
	
	public Mammal() {
		super();
		this.energyLevel = 100;
	}



	public Integer displayEnergy() {
		System.out.println(this.energyLevel);
		return this.energyLevel;
	}
}
