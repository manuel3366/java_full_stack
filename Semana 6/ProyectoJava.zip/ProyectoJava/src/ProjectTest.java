import java.util.ArrayList;

public class ProjectTest {

	public static void main(String[] args) {
		String nombre = "Proyecto Java";
		String descripcion = "Es un proyecto de Java Fundamentals.";
		double initialCost = 1500.0;
		Project project = new Project(nombre, descripcion, initialCost);
		String texto = project.elevatorPitch();
		System.out.println(texto);
		
		String nombre2 = "Projecto Python";
		String descripcion2 = "Es un proyecto de Python";
		double initialCost2 = 13500.0;
		Project project2 = new Project(nombre2, descripcion2, initialCost2);
		
		ArrayList<Project> projects = new ArrayList<Project>();
		projects.add(project);
		projects.add(project2);
		
		Portfolio portfolio = new Portfolio(projects);
		portfolio.showPortfolio();

	}

}
