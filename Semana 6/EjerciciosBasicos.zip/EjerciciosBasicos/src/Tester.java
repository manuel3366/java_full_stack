
public class Tester {

	public static void main(String[] args) {
		Impresion impresion = new Impresion();
		impresion.imprimirDesdeHasta(1, 255);
		
		Arreglo arreglo = new Arreglo();
		int[] array = {-23, -25, -1};
		int valorMaximo = arreglo.obtenerValorMaximo(array);
		System.out.println(valorMaximo);
	}

}
