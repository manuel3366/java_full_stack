
public class Arreglo {
	public int obtenerValorMaximo(int[] array) {
		int valorMaximo = 0;
		for(int i = 0; i < array.length; i++) {
			if (i == 0) {
				valorMaximo = array[i];
			}
			if (valorMaximo < array[i]) {
				valorMaximo = array[i];
			}
		}
		return valorMaximo;
	}
}
