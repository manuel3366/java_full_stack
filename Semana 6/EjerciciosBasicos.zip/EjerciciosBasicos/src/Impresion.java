
public class Impresion {
	public void imprimirDesdeHasta(int desde, int hasta) {		
		for(int i = desde; i <= hasta; i++) {
			System.out.println(i);
		}
	}
}
