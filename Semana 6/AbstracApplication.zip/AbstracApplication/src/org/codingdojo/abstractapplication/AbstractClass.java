package org.codingdojo.abstractapplication;

public abstract class AbstractClass {
	public void randomMethod() {
        System.out.println("Este es un método aleatorio que es implementado en esta clase");
    }
	
	//Método Abstracto
    public abstract void abstractMethod();
}
