package org.codingdojo.abstractapplication;

public class SubClassOne extends AbstractClass{

	@Override
	public void abstractMethod() {
		System.out.println("Este es nuestro método de la SubClassOne");
	}

}
