package org.codingdojo.abstractapplication;

public class SubClassTwo extends AbstractClass {

	@Override
	public void abstractMethod() {		
		System.out.println("Este es nuestro método de la SubClassTwo");
	}

}
