package org.codingdojo.abstractapplication.tester;

import org.codingdojo.abstractapplication.SubClassOne;
import org.codingdojo.abstractapplication.SubClassTwo;

public class AbstractTester {
	public static void main(String[] args) {
		SubClassOne subClassOne = new SubClassOne();
		subClassOne.randomMethod();
		subClassOne.abstractMethod();
		
		SubClassTwo subClassTwo = new SubClassTwo();
		subClassTwo.randomMethod();
		subClassTwo.abstractMethod();
	}
}
