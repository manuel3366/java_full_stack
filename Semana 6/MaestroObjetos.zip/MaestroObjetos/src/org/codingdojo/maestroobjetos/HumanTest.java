package org.codingdojo.maestroobjetos;

import org.codingdojo.maestroobjetos.model.Human;

public class HumanTest {

	public static void main(String[] args) {
		Human humano1 = new Human();
		Human victima = new Human();
		humano1.attack(victima);
		humano1.attack(victima);
		System.out.println(victima.getHealth());
		humano1.attack(humano1);
		System.out.println(humano1.getHealth());
		

	}

}
