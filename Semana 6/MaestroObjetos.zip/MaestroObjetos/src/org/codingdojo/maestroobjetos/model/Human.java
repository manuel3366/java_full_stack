package org.codingdojo.maestroobjetos.model;

public class Human {
	private Integer strength;
	private Integer stealth;
	private Integer intelligence;
	private Integer health;
	
	public Human() {
		this.strength = 3;
		this.stealth = 3;
		this.intelligence = 3;
		this.health = 100;
	}
	
	public void attack(Human human) {
		human.setHealth(human.getHealth() - this.strength);
	}

	public Integer getStrength() {
		return strength;
	}

	public Integer getStealth() {
		return stealth;
	}

	public Integer getIntelligence() {
		return intelligence;
	}

	public Integer getHealth() {
		return health;
	}

	public void setStrength(Integer strength) {
		this.strength = strength;
	}

	public void setStealth(Integer stealth) {
		this.stealth = stealth;
	}

	public void setIntelligence(Integer intelligence) {
		this.intelligence = intelligence;
	}

	public void setHealth(Integer health) {
		this.health = health;
	}
	
	
}
